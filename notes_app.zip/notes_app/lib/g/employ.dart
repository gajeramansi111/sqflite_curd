// import 'package:flutter/material.dart';
// import 'package:notes_app/g/helpers.dart';
//
// import 'dart:async';
//
// import 'model.dart';
//
// Future<Future<List?>> fetchEmployeesFromDatabase() async {
//   var dbHelper = DBHelper();
//   Future<List> employees = dbHelper.getEmployees();
//   return employees;
// }
//
// class MyEmployeeList extends StatefulWidget {
//   @override
//   MyEmployeeListPageState createState() => new MyEmployeeListPageState();
// }
//
// class MyEmployeeListPageState extends State<MyEmployeeList> {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: new AppBar(
//         title: new Text('Employee List'),
//       ),
//       body: Container(
//         padding: new EdgeInsets.all(16.0),
//         child: FutureBuilder<List<Employee>>(
//           future: fetchEmployeesFromDatabase(),
//           builder: (context, snapshot) {
//             if (snapshot.hasData) {
//               return ListView.builder(
//                   itemCount: snapshot.data!.length,
//                   itemBuilder: (context, index) {
//                     return Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: <Widget>[
//                           Text(snapshot.data![index].firstName,
//                               style: const TextStyle(
//                                   fontWeight: FontWeight.bold, fontSize: 18.0)),
//                           Text(snapshot.data![index].lastName,
//                               style: const TextStyle(
//                                   fontWeight: FontWeight.bold, fontSize: 14.0)),
//                           new Divider()
//                         ]);
//                   });
//             } else if (snapshot.hasError) {
//               return new Text("${snapshot.error}");
//             }
//             return new Container(
//               alignment: AlignmentDirectional.center,
//               child: new CircularProgressIndicator(),
//             );
//           },
//         ),
//       ),
//     );
//   }
// }
