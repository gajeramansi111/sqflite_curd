import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:notes_app/the_tech/sql_helpers.dart';
import 'add_page.dart';
import 'notes_model.dart';

class NoteHomePage extends StatefulWidget {
  const NoteHomePage({Key? key}) : super(key: key);

  @override
  State<NoteHomePage> createState() => _NoteHomePageState();
}

class _NoteHomePageState extends State<NoteHomePage> {
  DBHelper? dbHelper;
  List<NotesModel>? notesList;
  List<NotesModel> datas = [];
  bool fetching = true;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    dbHelper = DBHelper();
    getData();
    fetching = false;
  }

  void getData() async {
    datas = await dbHelper!.getNotesList();
  }

  Future<List<NotesModel>> loadData() async {
    notesList = (await dbHelper!.getNotesList());
    print("notesList $notesList");
    return notesList ?? [];
  }

  final TextEditingController mynotesController = TextEditingController();
  final TextEditingController decrioption = TextEditingController();

  ImagePicker picker = ImagePicker();

  final formkey = GlobalKey<FormState>();

  List<String> selectedImages = [];
  File? file;
  bool selected = true;

  Future getImages() async {
    final pickedFile = await picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 100,
        maxHeight: 1000,
        maxWidth: 1000);
    List<XFile> xfilePick = pickedFile as List<XFile>;

    setState(
      () {
        if (xfilePick.isNotEmpty) {
          for (var i = 0; i < xfilePick.length; i++) {
            File imageFile = File(xfilePick[i].path);
            selectedImages.add(imageFile.path);
          }
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Nothing is selected')));
        }
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(children: [
        Expanded(
          child: FutureBuilder(
            future: loadData(),
            builder: (context, AsyncSnapshot<List<NotesModel>> snapshot) {
              print(snapshot.connectionState);
              if (snapshot.hasData) {
                return ListView.builder(
                  // reverse: true,
                  itemCount: snapshot.data?.length,
                  itemBuilder: (context, index) {
                    return InkWell(
                      onTap: () {
                        dbHelper!.update(NotesModel(
                          id: snapshot.data![index].id!,
                          title: "firstname",
                          description: 'let me talk to tomorrow',
                          image: selectedImages,
                        ));
                        setState(() {});
                      },
                      child: Dismissible(
                        direction: DismissDirection.endToStart,
                        background: Container(
                          color: Colors.red,
                          child: const Icon(Icons.delete_outline),
                        ),
                        onDismissed: (DismissDirection direction) {
                          setState(() {
                            dbHelper!
                                .delete(snapshot.data![index].id!)
                                .then((value) => print("deleted id $value"));
                            getData();

                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text("Note's is Deleted"),
                              ),
                            );
                          });
                        },
                        key: ValueKey(snapshot.data![index].id!),
                        child: Card(
                          child: ListTile(
                            leading: Image.file(
                                File(snapshot.data![index].image.toString())),
                            title: Text(snapshot.data![index].title.toString()),
                            subtitle: Text(
                                snapshot.data![index].description.toString()),
                          ),
                        ),
                      ),
                    );
                  },
                );
              } else {
                return const Center(child: CircularProgressIndicator());
              }
            },
          ),
        )
      ]),
      floatingActionButton: FloatingActionButton(
          onPressed: () {
            // Navigator.push(
            //     context,
            //     MaterialPageRoute(
            //       builder: (context) => AddPage(),
            //     ));
            showDialog(
              context: context,
              builder: (context) {
                return Dialog(
                  child: Column(
                    children: [
                      TextFormField(
                        controller: mynotesController,
                        onChanged: (value) {},
                        maxLines: 3,
                        decoration: const InputDecoration(hintText: "title"),
                      ),
                      TextFormField(
                        controller: decrioption,
                        onChanged: (value) {},
                        maxLines: 3,
                        decoration:
                            const InputDecoration(hintText: "description"),
                      ),
                      ElevatedButton(
                          onPressed: () {},
                          child: const Icon(Icons.mic_none_outlined)),
                      ElevatedButton(
                          onPressed: () {
                            getImages();
                          },
                          child: const Icon(Icons.image)),
                      ElevatedButton(
                          onPressed: () async {
                            await dbHelper!.insert(NotesModel(
                                title: mynotesController.text,
                                description: decrioption.text,
                                image: selectedImages));
                            mynotesController.clear();
                            decrioption.clear();
                            Navigator.pop(context);
                          },
                          child: const Icon(Icons.check)),
                    ],
                  ),
                );
              },

              //     .then((value) {
              //   print('data added');
              //   setState(() {
              //     notesList = dbHelper!.getNotesList();
              //   });
              // }).onError((error, stackTrace) {
              //   print(error.toString());
              // }
            );
          },
          child: const Icon(Icons.add)),
    );
  }

// @override
// void debugFillProperties(DiagnosticPropertiesBuilder properties) {
//   super.debugFillProperties(properties);
//   properties.add(
//       DiagnosticsProperty<Future<List<NotesModel>>>('notesList', notesList));
// }
}

//
// class Utility {
//   static Image imageFromBase64String(String base64String) {
//     return Image.memory(
//       base64Decode(base64String),
//       fit: BoxFit.fill,
//     );
//   }
//
//   static Uint8List dataFromBase64String(String base64String) {
//     return base64Decode(base64String);
//   }
//
//   static String base64String(Uint8List data) {
//     return base64Encode(data);
//   }
// }
