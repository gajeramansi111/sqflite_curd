class NotesModel {
  final int? id;
  final String title;
  final String description;
  final List<String>? image;

  NotesModel({
    this.id,
    required this.title,
    required this.description,
    required this.image,
  });

  NotesModel.fromMap(
    Map<String, dynamic> res,
  )   : id = res['id'],
        title = res['title'],
        description = res['description'],
        image = res['image'];

  Map<String, Object?> toMap() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'image': image
    };
  }
}
