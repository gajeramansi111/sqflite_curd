// import 'package:flutter/material.dart';
// import 'package:notes_app/the_tech/sql_helpers.dart';
//
// import 'home_screen.dart';
// import 'notes_model.dart';
//
// class AddPage extends StatefulWidget {
//   const AddPage({Key? key}) : super(key: key);
//
//   @override
//   State<AddPage> createState() => _AddPageState();
// }
//
// class _AddPageState extends State<AddPage> {
//   DBHelper? dbHelper;
//   TextEditingController notes = TextEditingController();
//   TextEditingController description = TextEditingController();
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Column(
//         children: [
//           SizedBox(
//             height: 50,
//           ),
//           TextFormField(
//             controller: notes,
//             decoration: InputDecoration(hintText: "my notes"),
//           ),
//           TextFormField(
//             controller: description,
//             decoration: InputDecoration(hintText: "my notes"),
//           ),
//           Spacer(),
//           Padding(
//             padding: const EdgeInsets.only(bottom: 20),
//             child: Row(
//               mainAxisAlignment: MainAxisAlignment.spaceAround,
//               children: [
//                 ElevatedButton(
//                   onPressed: () {},
//                   child: const Icon(Icons.mic_none),
//                 ),
//                 ElevatedButton(
//                   onPressed: () async {
//                     // getImages();
//                   },
//                   child: const Icon(Icons.image),
//                 ),
//                 ElevatedButton(
//                     onPressed: () async {
//                       await dbHelper!.insert(NotesModel(
//                         title: notes.text,
//                         description: description.text,
//                       ));
//                       notes.clear();
//                       description.clear();
//                       // Navigator.push(
//                       //     context,
//                       //     MaterialPageRoute(
//                       //       builder: (context) => NoteHomePage(),
//                       //     ));
//                       Navigator.pop(context);
//                     },
//                     child: Icon(Icons.check))
//               ],
//             ),
//           )
//         ],
//       ),
//     );
//   }
// }
