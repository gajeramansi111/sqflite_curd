// import 'dart:io';
//
// import 'package:flutter/material.dart';
// import 'package:image_picker/image_picker.dart';
// import 'package:notes_app/model.dart';
// import 'package:notes_app/notes_page.dart';
//
// import 'helpers.dart';
//
// class AddNotes extends StatefulWidget {
//   const AddNotes({Key? key}) : super(key: key);
//
//   @override
//   State<AddNotes> createState() => _AddNotesState();
// }
//
// class _AddNotesState extends State<AddNotes> {
//   ImagePicker picker = ImagePicker();
//
//   final formkey = GlobalKey<FormState>();
//
//   List<File> selectedImages = [];
//   File? file;
//
//   Future getImages() async {
//     final pickedFile = await picker.pickMultiImage(
//         imageQuality: 100, maxHeight: 1000, maxWidth: 1000);
//     List<XFile> xfilePick = pickedFile;
//
//     setState(
//       () {
//         if (xfilePick.isNotEmpty) {
//           for (var i = 0; i < xfilePick.length; i++) {
//             selectedImages.add(File(xfilePick[i].path));
//           }
//         } else {
//           ScaffoldMessenger.of(context).showSnackBar(
//               const SnackBar(content: Text('Nothing is selected')));
//         }
//       },
//     );
//   }
//
//   final TextEditingController mynotesController = TextEditingController();
//   final TextEditingController decrioption = TextEditingController();
//   DBHelper? dbHelper;
//   Future<List<NotesModel>>? notesList;
//
//   void initState() {
//     // TODO: implement initState
//     super.initState();
//     dbHelper = DBHelper();
//   }
//
//   var title = '';
//   var descrioption = '';
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//           backgroundColor: Colors.redAccent,
//           title: Text("Add Notes"),
//           leading: IconButton(
//             onPressed: () async {
//               // await DatabaseHelper.instance.insertRecord({
//               //   DatabaseHelper.columnName: mynotesController
//               // }).then((value) => Navigator.pop(context));
//               Navigator.pop(context);
//             },
//             icon: const Icon(
//               Icons.arrow_back,
//               color: Colors.white,
//             ),
//           )),
//       body: Container(
//           height: MediaQuery.of(context).size.height,
//           width: MediaQuery.of(context).size.width,
//           child: Column(
//             children: [
//               TextFormField(
//                 controller: mynotesController,
//                 onChanged: (value) {
//                   title = value;
//                   print(title);
//                 },
//                 maxLines: 5,
//                 //  maxLength: 1000,
//                 decoration: const InputDecoration(
//                     hintText: "My Notes",
//                     labelText: "My Notes",
//                     focusedBorder:
//                         UnderlineInputBorder(borderSide: BorderSide.none)),
//               ),
//               TextFormField(
//                 controller: decrioption,
//                 onChanged: (value) {
//                   descrioption = value;
//                   print(descrioption);
//                 },
//                 //  maxLength: 1000,
//                 decoration: const InputDecoration(
//                     hintText: "My Notes",
//                     labelText: "My Notes",
//                     focusedBorder:
//                         UnderlineInputBorder(borderSide: BorderSide.none)),
//               ),
//               Expanded(
//                 child: SizedBox(
//                   width: 300.0,
//                   child: selectedImages.isEmpty // If no images is selected
//                       ? const Center(child: Text(''))
//                       : GridView.builder(
//                           itemCount: selectedImages.length,
//                           gridDelegate:
//                               const SliverGridDelegateWithFixedCrossAxisCount(
//                                   crossAxisCount: 3),
//                           itemBuilder: (BuildContext context, int index) {
//                             // TO show selected file
//                             return Center(
//                                 child: Image.file(selectedImages[index]));
//                           },
//                         ),
//                 ),
//               ),
//               const Spacer(),
//               Padding(
//                 padding: const EdgeInsets.only(bottom: 20),
//                 child:
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.spaceAround,
//                   children: [
//                     ElevatedButton(
//                       onPressed: () {},
//                       child: const Icon(Icons.mic_none),
//                     ),
//                     ElevatedButton(
//                       onPressed: () async {
//                         getImages();
//                       },
//                       child: const Icon(Icons.image),
//                     ),
//                     ElevatedButton(
//                       onPressed: () {
//                         dbHelper!
//                             .insert(NotesModel(
//                           title: mynotesController.text,
//                           description: decrioption.text,
//                         ))
//                             .then((value) {
//                           setState(() {
//                             notesList = dbHelper!.getNotesList();
//                           });
//                         }).then((value) {
//                           Navigator.push(
//                               context,
//                               MaterialPageRoute(
//                                 builder: (context) => NotesPage(),
//                               ));
//                         });
//                       },
//                       child: const Icon(Icons.check),
//                     ),
//                   ],
//                 ),
//               )
//             ],
//           )),
//     );
//   }
// }
