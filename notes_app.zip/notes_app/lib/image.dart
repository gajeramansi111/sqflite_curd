// import 'package:flutter/material.dart';
// import 'package:image_picker/image_picker.dart';
// import 'package:notes_app/the_tech/sql_helpers.dart';
// import 'package:path_provider/path_provider.dart';
// import 'package:sqflite/sqflite.dart';
// import 'dart:io';
// import 'package:path/path.dart';
// import 'dart:async';
//
// class SaveImageDemoSQLite extends StatefulWidget {
//   //
//   SaveImageDemoSQLite() : super();
//
//   final String title = "Flutter Save Image";
//
//   @override
//   _SaveImageDemoSQLiteState createState() => _SaveImageDemoSQLiteState();
// }
//
// class _SaveImageDemoSQLiteState extends State<SaveImageDemoSQLite> {
//   //
//   Future<File>? imageFile;
//   ImagePicker picker = ImagePicker();
//   Image? image;
//   DBHelper? dbHelper;
//   List<Photo>? images;
//
//   @override
//   void initState() {
//     super.initState();
//     images = [];
//
//     refreshImages();
//   }
//
//   refreshImages() {
//     dbHelper!.getPhotos().then((imgs) {
//       setState(() {
//         images!.clear();
//         images!.addAll(imgs);
//       });
//     });
//   }
//
//   pickImageFromGallery() async {
//     picker = await ImagePicker.pickImage(source: ImageSource.gallery)
//         .then((imgFile) {
//       String imgString = Utility.base64String(imgFile.readAsBytesSync());
//       Photo photo = Photo(0, imgString);
//       dbHelper!.save(photo);
//       refreshImages();
//     });
//   }
//
//   gridView() {
//     return Padding(
//       padding: EdgeInsets.all(5.0),
//       child: GridView.count(
//         crossAxisCount: 2,
//         childAspectRatio: 1.0,
//         mainAxisSpacing: 4.0,
//         crossAxisSpacing: 4.0,
//         children: images!.map((photo) {
//           return Utility.imageFromBase64String(photo.photoName);
//         }).toList(),
//       ),
//     );
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text(widget.title),
//         actions: <Widget>[
//           IconButton(
//             icon: Icon(Icons.add),
//             onPressed: () {
//               pickImageFromGallery();
//             },
//           )
//         ],
//       ),
//       body: Center(
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.start,
//           children: <Widget>[
//             Flexible(
//               child: gridView(),
//             )
//           ],
//         ),
//       ),
//     );
//   }
// }
//
// class DBHelper {
//   static Database? _db;
//   static const String ID = 'id';
//   static const String NAME = 'photo_name';
//   static const String TABLE = 'PhotosTable';
//   static const String DB_NAME = 'photos.db';
//
//   Future<Database?> get db async {
//     if (null != _db) {
//       return _db;
//     }
//     _db = await initDb();
//     return _db;
//   }
//
//   initDb() async {
//     io.Directory documentsDirectory = await getApplicationDocumentsDirectory();
//     String path = join(documentsDirectory.path, DB_NAME);
//     var db = await openDatabase(path, version: 1, onCreate: _onCreate);
//     return db;
//   }
//
//   _onCreate(Database db, int version) async {
//     await db.execute("CREATE TABLE $TABLE ($ID INTEGER, $NAME TEXT)");
//   }
//
//   Future<Photo> save(Photo employee) async {
//     var dbClient = await db;
//     employee.id = await dbClient!.insert(TABLE, employee.toMap());
//     return employee;
//   }
//
//   Future<List<Photo>> getPhotos() async {
//     var dbClient = await db;
//     List<Map> maps = await dbClient!.query(TABLE, columns: [ID, NAME]);
//     List<Photo> employees = [];
//     if (maps.length > 0) {
//       for (int i = 0; i < maps.length; i++) {}
//     }
//     return employees;
//   }
//
//   Future close() async {
//     var dbClient = await db;
//     dbClient!.close();
//   }
// }
//
// //class
// class Photo {
//   int id;
//   String photo_name;
//
//   Photo(this.id, this.photo_name);
//
//   Map<String, dynamic> toMap() {
//     var map = <String, dynamic>{
//       'id': id,
//       'photo_name': photo_name,
//     };
//     return map;
//   }
//
//   Photo.fromMap(Map<String, dynamic> map) {
//     id = map['id'];
//     photo_name = map['photo_name'];
//   }
// }
