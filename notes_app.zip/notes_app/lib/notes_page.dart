// import 'package:flutter/material.dart';
//
// import 'add_notes.dart';
// import 'helpers.dart';
// import 'model.dart';
//
// class NotesPage extends StatefulWidget {
//   final title;
//   final decrioption;
//   const NotesPage({Key? key, this.title, this.decrioption}) : super(key: key);
//
//   @override
//   State<NotesPage> createState() => _NotesPageState();
// }
//
// int count = 0;
//
// class _NotesPageState extends State<NotesPage> {
//   DBHelper? dbHelper;
//   Future<List<NotesModel>>? notesList;
//   void initState() {
//     // TODO: implement initState
//     super.initState();
//     dbHelper = DBHelper();
//   }
//
//   loadData() async {
//     notesList = dbHelper!.getNotesList();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar:
//           AppBar(backgroundColor: Colors.redAccent, title: Text("My Notes")),
//       body: Column(
//         children: [
//           Expanded(
//             child: FutureBuilder(
//               future: notesList,
//               builder: (context, AsyncSnapshot<List<NotesModel>> snapshot) {
//                 if (snapshot.hasData) {
//                   return ListView.builder(
//                     // reverse: true,
//                     itemCount: snapshot.data?.length,
//                     itemBuilder: (context, index) {
//                       return InkWell(
//                         onTap: () {
//                           dbHelper!.update(NotesModel(
//                             id: snapshot.data![index].id!,
//                             title: widget.title,
//                             description: widget.decrioption,
//                           ));
//                           setState(() {
//                             notesList = dbHelper!.getNotesList();
//                           });
//                         },
//                         child: Dismissible(
//                           direction: DismissDirection.endToStart,
//                           background: Container(
//                             color: Colors.red,
//                             child: Icon(Icons.delete_outline),
//                           ),
//                           onDismissed: (DismissDirection direction) {
//                             setState(() {
//                               dbHelper!.delete(snapshot.data![index].id!);
//                               notesList = dbHelper!.getNotesList();
//                               snapshot.data!.remove(snapshot.data![index]);
//                             });
//                           },
//                           key: ValueKey(snapshot.data![index].id!),
//                           child: Card(
//                             child: ListTile(
//                               title: widget.title,
//                               subtitle: Text(widget.decrioption),
//                             ),
//                           ),
//                         ),
//                       );
//                     },
//                   );
//                 } else {
//                   return const Center(child: CircularProgressIndicator());
//                 }
//               },
//             ),
//           )
//         ],
//       ),
//       floatingActionButton: FloatingActionButton(
//           onPressed: () {
//             Navigator.push(
//                 context,
//                 MaterialPageRoute(
//                   builder: (context) => AddNotes(),
//                 ));
//           },
//           child: const Icon(
//             Icons.add,
//             color: Colors.blueAccent,
//           )),
//     );
//   }
// }
