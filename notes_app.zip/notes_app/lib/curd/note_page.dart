// import 'package:flutter/material.dart';
// import 'package:notes_app/curd/data_base_helper.dart';
//
// import '../add_notes.dart';
//
// class NotePage extends StatefulWidget {
//   const NotePage({Key? key}) : super(key: key);
//
//   @override
//   State<NotePage> createState() => _NotePageState();
// }
//
// class _NotePageState extends State<NotePage> {
//   final dbhelper = DatabaseHelper.instance;
//
//   void insertdata() async {
//     Map<String, dynamic> row = {};
//   }
//
//   List<Map<String, dynamic>> showData = [];
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Column(
//         children: [
//           Expanded(
//             child: ListView.builder(
//               itemCount: showData.length,
//               itemBuilder: (context, index) {
//                 return Column(
//                   children: [
//                     Text('${showData[index]['name']}'),
//                   ],
//                 );
//               },
//             ),
//           )
//         ],
//       ),
//       floatingActionButton: FloatingActionButton(
//           onPressed: () {
//             Navigator.push(
//                 context,
//                 MaterialPageRoute(
//                   builder: (context) => AddNotes(),
//                 ));
//           },
//           child: Icon(
//             Icons.add,
//             color: Colors.blueAccent,
//           )),
//     );
//   }
// }
