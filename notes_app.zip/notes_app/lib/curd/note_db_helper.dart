import 'dart:io';

import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class NoteDbHelper {
  static const dbName = "notes.db";
  static const dbVersion = 1;
  static const tablename = "notes";
  static const colid = "id";
  static const coltitle = "title";
  static const coldescriotion = "descriotion";

  static final NoteDbHelper instance = NoteDbHelper();
  static Database? niranjandb;

  Future<Database?> get db async {
    niranjandb ??= await initDb();
    return niranjandb;
  }

  Future<Database> initDb() async {
    Directory documentdirectory = await getApplicationDocumentsDirectory();

    String path = join(documentdirectory.path, dbName);
    return await openDatabase(path, version: dbVersion, onCreate: onCreate);
  }

  onCreate(Database db, int version) async {
    db.execute('''' CREATE TABLE $tablename(
    
      $colid INTEGER PRIMARY KEY,
    $coltitle TEXT NOT NULL,
    $coldescriotion TEXT NOT NULL,
    )   ''');
  }

  Future<int> insert(Map<String, dynamic> row) async {
    Database? db = await instance.db;
    return await db!.insert(tablename, row);
  }

  Future<List<Map<String, dynamic>>?> queryAll() async {
    Database? db = await instance.db;
    return await db!.query(tablename);
  }

//   Future<int> update(<Map<String,dynamic>row>)async{
//   Database? db = await instance.db;
//   int id=row[colid];
//   return await db!.update(tablename, row,where: '$colid=?',whereArgs: [id]);
// }

  Future<int> deleteRecord(int id) async {
    Database? db = await instance.db;
    return await db!.delete(tablename, where: '$colid=?', whereArgs: [id]);
  }

  Future close() async {
    Database? db = await instance.db;
    db!.close();
  }
}
